@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Peak Pact JOIN

echo.
echo  Ты ГОСТЬ (сервер крутится у друга-хоста)
echo  1. Radmin VPN — одна сеть с хостом
echo  2. Онлайн → IP: Radmin_IP_хоста:3000
echo  3. Код комнаты → Войти
echo.

set HTML=%~dp0peak-pact.html
set URL=file:///%HTML:\=/%
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
  start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="%URL%"
  goto :eof
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%URL%"
  goto :eof
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%URL%"
  goto :eof
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%URL%"
  goto :eof
)
start "" "%HTML%"
