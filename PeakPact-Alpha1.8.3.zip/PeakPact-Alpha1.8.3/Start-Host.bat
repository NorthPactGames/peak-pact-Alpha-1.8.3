@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Peak Pact HOST

where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ОШИБКА] Node.js не установлен!
  echo  Скачай: https://nodejs.org  (кнопка LTS)
  echo  Установи и запусти этот файл снова.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\socket.io\package.json" (
  echo Первый запуск: npm install...
  call npm install --no-fund --no-audit
  if errorlevel 1 (
    echo npm install не удался. Нужен интернет один раз.
    pause
    exit /b 1
  )
)

netstat -ano 2>nul | findstr ":3000" | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
  echo Запускаю сервер на этом ПК (база)...
  start "Peak Pact SERVER" /MIN cmd /c "cd /d \"%~dp0\" && node server.js & echo. & echo Сервер остановлен. & pause"
  timeout /t 3 /nobreak >nul
) else (
  echo Сервер уже работает — этот ПК = база.
)

echo.
echo  ============================================
echo   ТЫ ХОСТ. Этот компьютер = БАЗА комнаты.
echo   В игре: Онлайн → IP оставь ПУСТЫМ
echo           → Создать комнату → Создать
echo   Другу: свой Radmin IP + код комнаты
echo   Окно "Peak Pact SERVER" НЕ ЗАКРЫВАЙ
echo  ============================================
echo.

REM Открываем игру ЧЕРЕЗ сервер (http), тогда онлайн цепляется сам
set GAMEURL=http://127.0.0.1:3000/peak-pact.html

if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
  start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="%GAMEURL%"
  goto :done
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%GAMEURL%"
  goto :done
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%GAMEURL%"
  goto :done
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%GAMEURL%"
  goto :done
)
start "" "%GAMEURL%"

:done
exit /b 0
