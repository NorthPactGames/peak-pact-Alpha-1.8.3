Peak Pact Alpha 1.8.3 — North Pact Games

Установка: Install-PeakPact.bat
Онлайн: Start-Host.bat / Start-Join.bat

ДОНАТ → Telegram-бот → вывод на КАРТУ:
  1. Создай бота @BotFather
  2. DonationAlerts → вывод на карту
  3. В peak-pact.html: PAYMENT_CONFIG.telegramBot = '@твой_бот'
  Подробно: DONATE.txt

Ивент «Петля ужаса» выключен до 11.10.2027.
Включить: peak-pact.html → HORROR_EVENT_ENABLED=true
