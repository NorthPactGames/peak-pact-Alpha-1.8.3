/**
 * Peak Pact — сервер на ПК создателя комнаты (база)
 * Слушает 0.0.0.0:3000 → любой Radmin IP
 *
 * Хост:  Start-Host.bat  (сервер + игра), в игре IP пусто
 * Друг:  Start-Join.bat, IP = Radmin-IP_хоста:3000 + код комнаты
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');

const PORT = Number(process.env.PEAK_PORT) || 3000;
const ROOT = __dirname;

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.m4a': 'audio/mp4',
  '.mp3': 'audio/mpeg',
  '.svg': 'image/svg+xml'
};

const server = http.createServer((req, res) => {
  try {
    let urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
    if (urlPath === '/') urlPath = '/peak-pact.html';
    const file = path.normalize(path.join(ROOT, urlPath.replace(/^\//, '')));
    if (!file.startsWith(ROOT)) {
      res.writeHead(403); res.end('Forbidden'); return;
    }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404); res.end('Not found'); return; }
      const ext = path.extname(file).toLowerCase();
      res.writeHead(200, {
        'Content-Type': mime[ext] || 'application/octet-stream',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-store'
      });
      res.end(data);
    });
  } catch (e) {
    res.writeHead(500); res.end('Error');
  }
});

const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  transports: ['websocket', 'polling'],
  allowEIO3: true,
  pingInterval: 5000,
  pingTimeout: 15000
});

const rooms = new Map();

function genCode() {
  let c;
  do { c = String(Math.floor(1000 + Math.random() * 9000)); } while (rooms.has(c));
  return c;
}

function lobbyState(c) {
  const room = rooms.get(c);
  if (!room) return null;
  return {
    code: c,
    name: room.name,
    private: !!room.private,
    maxPlayers: room.maxPlayers,
    players: room.players.map(p => ({ slot: p.slot, name: p.name, id: p.id })),
    host: room.host,
    started: room.started,
    diff: room.diff,
    mapId: room.mapId
  };
}

function publicRoomList() {
  const list = [];
  for (const [c, room] of rooms) {
    if (room.private || room.started) continue;
    list.push({
      code: c,
      name: room.name,
      players: room.players.length,
      maxPlayers: room.maxPlayers,
      diff: room.diff
    });
  }
  return list;
}

io.on('connection', (socket) => {
  console.log('[+]', socket.id);
  socket.emit('room_list', publicRoomList());

  socket.on('list_rooms', () => {
    socket.emit('room_list', publicRoomList());
  });

  socket.on('create', (data = {}) => {
    try {
      const roomName = String(data.roomName || data.name || 'Room').trim().slice(0, 48) || 'Room';
      const isPrivate = !!(data.isPrivate || data.private);
      let maxPlayers = parseInt(data.maxPlayers, 10);
      if (!Number.isFinite(maxPlayers)) maxPlayers = 4;
      maxPlayers = Math.max(1, Math.min(10, maxPlayers));
      const playerName = String(data.playerName || 'Host').trim().slice(0, 24) || 'Host';

      let c = String(data.code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (c) {
        if (rooms.has(c)) {
          socket.emit('err', 'Код уже занят');
          return;
        }
      } else {
        c = genCode();
      }

      rooms.set(c, {
        name: roomName,
        private: isPrivate,
        maxPlayers,
        players: [{ id: socket.id, name: playerName, slot: 0 }],
        host: socket.id,
        started: false,
        seed: null,
        diff: data.diff || 'easy',
        mapId: data.mapId || 0
      });

      socket.join(c);
      socket.room = c;
      socket.slot = 0;
      socket.emit('created', {
        code: c,
        slot: 0,
        name: roomName,
        private: isPrivate
      });
      io.to(c).emit('lobby', lobbyState(c));
      io.emit('room_list', publicRoomList());
      console.log('[room]', c, roomName);
    } catch (e) {
      console.error(e);
      socket.emit('err', String(e.message || e));
    }
  });

  socket.on('join', (data = {}) => {
    try {
      const raw = String(data.code || '').trim();
      const c = raw.toUpperCase();
      const room = rooms.get(c) || rooms.get(raw);
      if (!room) return socket.emit('err', 'Комната не найдена');
      if (room.players.length >= room.maxPlayers) return socket.emit('err', 'Комната заполнена');
      if (room.started) return socket.emit('err', 'Игра уже началась');

      const playerName = String(data.playerName || data.name || 'Guest').trim().slice(0, 24) || 'Guest';
      const used = new Set(room.players.map(p => p.slot));
      let slot = 0;
      while (used.has(slot) && slot < 10) slot++;

      room.players.push({ id: socket.id, name: playerName, slot });
      socket.join(room.code || c);
      socket.room = room.code || c;
      socket.slot = slot;

      // ensure map key is consistent
      if (!rooms.has(socket.room) && rooms.has(c)) {
        /* ok */
      }

      socket.emit('joined', {
        code: socket.room,
        slot,
        diff: room.diff,
        mapId: room.mapId,
        seed: room.seed,
        name: room.name
      });
      io.to(socket.room).emit('lobby', lobbyState(socket.room));
      io.emit('room_list', publicRoomList());
      console.log('[join]', socket.room, 'slot', slot);
    } catch (e) {
      socket.emit('err', String(e.message || e));
    }
  });

  socket.on('start', () => {
    const c = socket.room;
    const room = rooms.get(c);
    if (!room || room.host !== socket.id) {
      socket.emit('err', 'Только хост может начать');
      return;
    }
    room.started = true;
    room.seed = Date.now() % 100000;
    io.to(c).emit('start', {
      seed: room.seed,
      diff: room.diff,
      mapId: room.mapId,
      players: room.players.map(p => ({ slot: p.slot, name: p.name }))
    });
    io.emit('room_list', publicRoomList());
    console.log('[start]', c);
  });

  socket.on('input', (data) => {
    const c = socket.room;
    if (!c) return;
    socket.to(c).emit('input', Object.assign({}, data || {}, { slot: socket.slot }));
  });

  socket.on('state', (data) => {
    const c = socket.room;
    if (!c) return;
    socket.to(c).emit('state', Object.assign({}, data || {}, { slot: socket.slot }));
  });

  socket.on('event', (data) => {
    const c = socket.room;
    if (!c) return;
    socket.to(c).emit('event', Object.assign({}, data || {}, { slot: socket.slot }));
  });

  socket.on('disconnect', () => {
    const c = socket.room;
    if (!c) return;
    const room = rooms.get(c);
    if (!room) return;
    room.players = room.players.filter(p => p.id !== socket.id);
    if (room.players.length === 0) {
      rooms.delete(c);
      console.log('[del]', c);
    } else {
      if (room.host === socket.id) room.host = room.players[0].id;
      io.to(c).emit('lobby', lobbyState(c));
      io.to(c).emit('peer_left', { left: socket.id });
    }
    io.emit('room_list', publicRoomList());
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  ========================================');
  console.log('  Peak Pact SERVER — этот ПК = БАЗА');
  console.log('  ========================================');
  console.log('  Local:  http://127.0.0.1:' + PORT);
  try {
    const os = require('os');
    const nets = os.networkInterfaces();
    for (const name of Object.keys(nets)) {
      for (const n of nets[name] || []) {
        if ((n.family === 'IPv4' || n.family === 4) && !n.internal) {
          console.log('  Друг пишет:  ' + n.address + ':' + PORT);
        }
      }
    }
  } catch (e) {}
  console.log('  Окно НЕ ЗАКРЫВАЙ, пока играют.');
  console.log('');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error('Порт ' + PORT + ' занят. Закрой другой server.js');
  } else console.error(err);
  process.exit(1);
});
