# Peak Pact Alpha 1.8.3

Кооперативный платформер (верёвка, предательство, вершины). **North Pact Games**

## Структура

```
PeakPact-Alpha1.8.3/
  Install-PeakPact.bat   — установка + ярлык
  PeakPact.vbs           — запуск без браузера/консоли
  Start-Host.bat         — онлайн: хост (сервер + игра)
  Start-Join.bat         — онлайн: гость
  peak-pact.html         — игра (последняя версия)
  server.js              — Socket.IO сервер 0.0.0.0:3000
  game/                  — копия для установщика
  node_modules/          — зависимости сервера
```

## Запуск

| Режим | Как |
|--------|-----|
| Соло / вдвоём | `Install-PeakPact.bat` или `PeakPact.vbs` |
| Онлайн-хост | `Start-Host.bat` (нужен Node.js) |
| Онлайн-гость | `Start-Join.bat` + Radmin IP хоста |

## Changelog (поверх GitHub 24.10)

- Скин **Билл Шифр** (promo / Halloween crate)
- Скин ТТ **Кровавая легенда**
- Промо **`31OCTOBER`**
- Онлайн: хост всегда 127.0.0.1, Radmin IP для гостей
- `Start-Host.bat` / `Start-Join.bat`
- Переводы ЛКМ/ПКМ на все языки
- Payhip донат https://payhip.com/b/xfm0t
